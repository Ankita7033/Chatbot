import os
from dotenv import load_dotenv
import google.generativeai as genai

# Load environment variables
load_dotenv()

# Get API key from environment
api_key = os.getenv('GEMINI_API_KEY')
print(f"API key found: {'Yes' if api_key else 'No'}")
print(f"API key length: {len(api_key) if api_key else 'N/A'}")

# Configure Gemini API
genai.configure(api_key=api_key)

# Test with the same model and approach as in app.py
try:
    # Try a different model
    model = genai.GenerativeModel("gemini-1.5-flash")
    
    # Use a simple prompt
    prompt = "Write a creative writing prompt about a space adventure."
    response = model.generate_content(prompt)
    
    print("\nTest response:")
    print(response.text)
    
    print("\nAPI test successful!")
    
except Exception as e:
    print(f"Error testing API: {str(e)}")