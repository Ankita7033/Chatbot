from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_socketio import SocketIO, emit
import google.generativeai as genai
import os
from dotenv import load_dotenv
import json
from datetime import datetime

# Load environment variables
load_dotenv()

# Configure Gemini API
gemini_api_key = os.getenv('GEMINI_API_KEY')
if not gemini_api_key:
    raise ValueError("GEMINI_API_KEY not found in environment variables")

# Debug print to confirm API key is loaded
print(f"API key loaded: {gemini_api_key[:5]}...")

genai.configure(api_key=gemini_api_key)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'your-secret-key')
socketio = SocketIO(app, async_mode='threading')

class WritingPromptBot:
    def __init__(self):
        self.conversation_history = []
        self.prompts_file = 'writing_prompts.json'
        self.genres = [
            "Fantasy", "Science Fiction", "Mystery", "Romance", "Horror", 
            "Historical", "Adventure", "Drama", "Comedy", "Thriller"
        ]
        self.chat_history = []
        self.load_chat_history()
        
    def load_chat_history(self):
        try:
            with open('chat_history.json', 'r') as f:
                self.chat_history = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.chat_history = []
            
    def save_chat_history(self):
        with open('chat_history.json', 'w') as f:
            json.dump(self.chat_history, f)
            
    def save_chat(self, content, sender):
        chat_entry = {
            'content': content,
            'sender': sender,
            'timestamp': datetime.now().isoformat()
        }
        self.chat_history.append(chat_entry)
        self.save_chat_history()
        
    def process_message(self, user_message):
        try:
            # Check if user is asking about who made the bot
            if any(phrase in user_message.lower() for phrase in ["who made", "who created", "who developed", "who built", "creator", "developer", "author"]):
                creators_info = "This chatbot was created by:\n\nAnkita - 12319054\nShashwat - 12319062\nDikshita - 12315945"
                
                # Save to chat history
                self.save_chat(user_message, 'user')
                self.save_chat(creators_info, 'assistant')
                
                return creators_info
            
            # Add user message to conversation history
            self.conversation_history.append({
                'role': 'user',
                'content': user_message
            })
            
            # Analyze message to determine if it's a scenario or a genre selection
            if "genre" in user_message.lower():
                response = self.handle_genre_selection(user_message)
            else:
                response = self.generate_prompt(user_message)
            
            # Add bot response to conversation history
            self.conversation_history.append({
                'role': 'assistant',
                'content': response
            })
            
            # Save to chat history
            self.save_chat(user_message, 'user')
            self.save_chat(response, 'assistant')
            
            return response
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def handle_genre_selection(self, user_message):
        # Extract genre from message
        for genre in self.genres:
            if genre.lower() in user_message.lower():
                return f"Great choice! I'll help you create prompts for {genre}. Please share a scenario or situation you'd like to explore in your story."
        
        # If no specific genre is mentioned, list available genres
        return "I can help you with these genres:\n" + "\n".join(self.genres) + "\n\nPlease let me know which one you're interested in!"
    
    def generate_prompt(self, scenario):
        # Generate a creative writing prompt based on the scenario
        try:
            # Debug print for API key
            api_key = os.getenv('GEMINI_API_KEY')
            print(f"Using API key in generate_prompt: {api_key[:5]}...")
            
            # Configure Gemini API
            genai.configure(api_key=api_key)
            
            # Use the correct model name
            model = genai.GenerativeModel('gemini-1.5-flash')  # Changed to a model that should work
            
            # Use a simple prompt
            prompt = f"Write a creative writing prompt about: {scenario}"
            print(f"Sending prompt: {prompt[:50]}...")
            
            response = model.generate_content(prompt)
            
            if hasattr(response, 'text'):
                return response.text
            else:
                return "I'm having trouble generating a prompt. Please try again with a different scenario."
                
        except Exception as e:
            error_message = str(e)
            print(f"API Error: {error_message}")  # Print full error for debugging
            if "API_KEY_INVALID" in error_message:
                return "Error: API key validation failed. Please check your API key configuration."
            elif "PERMISSION_DENIED" in error_message:
                return "Error: Permission denied. Your API key may not have access to this model."
            else:
                return f"Error generating prompt: {error_message}"
    
chat_bot = WritingPromptBot()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat')
def chat():
    return render_template('chat.html')

@app.route('/chat-history')
def get_chat_history():
    return jsonify(chat_bot.chat_history)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # For demonstration purposes, using a simple check
        # In a real app, you would validate against a database
        if username == 'admin' and password == 'password':
            # In a real app, you would use Flask-Login or similar
            # to manage user sessions
            return redirect(url_for('chat'))
        else:
            return render_template('login.html', error='Invalid username or password')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Here you would handle the signup logic
        # For now, we'll just redirect to the login page
        return redirect(url_for('login'))
    return render_template('signup.html')

@socketio.on('message')
def handle_message(data):
    user_message = data['message']
    print(f"Received message: {user_message}")  # Debug print
    
    # Emit typing indicator
    emit('typing', {'message': 'Bot is typing...'}, room=request.sid)
    
    # Generate response
    bot_response = chat_bot.process_message(user_message)
    print(f"Generated response: {bot_response}")  # Debug print
    
    # Emit bot response
    emit('response', {
        'message': bot_response,
        'timestamp': datetime.now().isoformat()
    }, room=request.sid)

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    # Configure socketio with CORS allowed
    socketio.run(app, debug=True, allow_unsafe_werkzeug=True, port=5001)
