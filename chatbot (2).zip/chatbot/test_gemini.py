import os
from dotenv import load_dotenv
import google.generativeai as genai

# Load environment variables
load_dotenv()

# Get API key from environment
api_key = os.getenv('GEMINI_API_KEY')
if not api_key:
    raise ValueError("GEMINI_API_KEY not found in environment variables")

# Configure Gemini API
genai.configure(api_key=api_key)

# Test API connection
def test_api_connection():
    try:
        # List available models
        models = genai.list_models()
        print("Available models:")
        for model in models:
            print(f"Model name: {model.name}")
            print(f"Description: {model.description}")
            print(f"Input token limit: {model.input_token_limit}")
            print(f"Output token limit: {model.output_token_limit}")
            print("-" * 50)
            
        # Test text generation using the Gemini model
        model = genai.GenerativeModel('gemini-1.5-pro')
        response = model.generate_content("Hello, how are you?")
        
        print("\nTest response:")
        print(response.text)
        
        print("\nAPI test successful!")
        
    except Exception as e:
        print(f"Error testing API: {str(e)}")

if __name__ == '__main__':
    test_api_connection()
